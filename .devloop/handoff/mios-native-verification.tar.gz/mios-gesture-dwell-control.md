<!-- AI-hint: Compiled native gesture positive, planted failure and restored-positive receipt. -->
# Native gesture neutral-dwell control

Source commit: `1861aca81411e89d7d6819ff9bd747ac30adabf1`.
Worktree: `/workspace/mios-gesture-continuation`.
Actual builder workdir: `/workspace/mios-gesture-continuation/tools/native`.
Explicit Cargo manifest: `/workspace/mios-gesture-continuation/tools/native/Cargo.toml`.
Original/restored router SHA-256: `96a5287225d59c49d766089e60bb7268bb654e749da00a02e35034b13ce96601`.

The shared `/workspace/mios-native-builder-state/mios-heavy.lock` was held across the entire ladder. Each command ran through the existing unprivileged prepared MiOS-DEV helper with explicit `MIOS_BUILD_WORKDIR`. The owned router was touched after acquiring the lock before each compile, preventing reuse of another worktree's shared-target test binary. Each positive reports one selected test plus 246 filtered tests, the expected 247-test inventory of this source.

Exact native command:

```sh
set -euo pipefail
printf 'PWD=%s\n' "$PWD"
printf 'MANIFEST=%s\n' /workspace/mios-gesture-continuation/tools/native/Cargo.toml
sha256sum /workspace/mios-gesture-continuation/tools/native/mios-inputd/src/router.rs /workspace/mios-gesture-continuation/tools/native/Cargo.toml
touch /workspace/mios-gesture-continuation/tools/native/mios-inputd/src/router.rs
cargo test --locked --manifest-path /workspace/mios-gesture-continuation/tools/native/Cargo.toml -p mios-inputd --target x86_64-unknown-linux-musl router::focus_gesture_contract::idle_neutral_ticks_arm_without_controller_frames -- --exact --nocapture
```

The plant changed only the tick sampler argument from `dt` to `0.0`, disabling elapsed neutral dwell. Compilation succeeded; the named native test failed at its `an idle pad emits no SYN_REPORT frames` assertion. Restoring the exact original bytes and recompiling made that same test pass. No other checkout or source content was altered.

| Stage | Exit | Router SHA-256 | Log SHA-256 |
| --- | ---: | --- | --- |
| positive | 0 | 96a5287225d59c49d766089e60bb7268bb654e749da00a02e35034b13ce96601 | ccc632155ec677d7e9e5c91189f2df09dfa939eb67af4c5ed6ba47af3a9c683a |
| plant | 101 | f1c40d27f5c77b6215dd1dcf220baa3089f73bf4c8cbb5b25fed9c872d88eab8 | 084bb27b4def3d8c240593e524fcca9c8101d061605d17d547e087b4751248eb |
| restored | 0 | 96a5287225d59c49d766089e60bb7268bb654e749da00a02e35034b13ce96601 | 4f6c2f9f2a9c7b1d7e0fbdced2f25588bb64c8f4c14ef3a59ca7c1491fcb3813 |

Logs:
- `/workspace/mios-native-builder-state/verification/mios-gesture-dwell-positive.log`
- `/workspace/mios-native-builder-state/verification/mios-gesture-dwell-plant.log`
- `/workspace/mios-native-builder-state/verification/mios-gesture-dwell-restored.log`

The owned worktree is clean at the original commit. No branch push or live controller/deployment claim is made. The integration owner publishes these evidence artifacts and the handoff through main.
