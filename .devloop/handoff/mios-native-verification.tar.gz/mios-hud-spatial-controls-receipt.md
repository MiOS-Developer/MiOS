# Compiled HUD spatial-navigation negative control

Source: `69a80a2462393862e16e9092a5c2be0617db3dc7`. Worktree: `/workspace/mios-hud-continuation`.
All three invocations ran as UID 1000 inside `podman-MiOS-DEV`, with Rust
1.99.1, Cargo 1.99.1 and target `x86_64-unknown-linux-musl`.

The host explicitly set
`MIOS_BUILD_WORKDIR=/workspace/mios-hud-continuation/tools/native` and supplied
`--manifest-path /workspace/mios-hud-continuation/tools/native/Cargo.toml`.
Each invocation sourced this worktree's `usr/lib/mios/heavy-lock.sh`, acquired
`/workspace/mios-native-builder-state/mios-heavy.lock`, and touched only its own
`ui.rs` after acquisition. Every log confirms the actual PWD, manifest, HEAD,
UID/toolchain and source digests, and a fresh compilation from this exact
worktree. The shared target did not supply another worktree's cached test
inventory: each execution ran one selected test with 432 filtered out, from
this source's 433-test library. The combined integration's 445-test library
includes additional camera work and is a different source inventory.

Command inside the lock:

```sh
cargo test --locked --manifest-path /workspace/mios-hud-continuation/tools/native/Cargo.toml -p mios-tamagotchi --target x86_64-unknown-linux-musl --lib ui::choice_menu_geometry_tests::real_painted_choices_publish_cardinal_navigation_without_charging_gameplay -- --exact --nocapture
```

| Phase | Actual native result |
| --- | --- |
| Original source | Compiled; 1 passed, 0 failed, 432 filtered out; exit 0 |
| Production spatial lookup replaced with linear navigation | Compiled; 0 passed, 1 failed, 432 filtered out; exit 101 |
| Exact source bytes restored | Compiled; 1 passed, 0 failed, 432 filtered out; exit 0 |

The plant replaced only the production `navigate_choice_menu` call
`spatial_menu_neighbor(&geometry.navigation, self.menu_selected, direction)`
with ordinary previous/next index arithmetic for the requested direction.
No test assertion was removed or changed. Right first selected index 1 as in
the real painted row; Down then incorrectly selected index 2 instead of the
painted grid's index 5. The named real-buffer/cardinal-navigation test failed
its `left == right` assertion at that behavior. This was a native assertion
failure after compilation, not a compile failure or zero-test invocation.
The bypass emitted an unused-`geometry` warning, which did not prevent the test
from compiling and executing.

Only the owned UI source was mutated. It was restored using its exact original
bytes in a protected `finally` block before the final positive build. Its
original and final SHA-256 are `4aa31a7caf306c583740da35629530f2c1814a3301e49836428b279870d391fc`.
The planted source SHA-256 was
`b45e7ff1cb02bab69aeff8a3f8cd91636085319457bf2fe35a70a416ff4f349f`.
Manifest SHA-256:
`fc42376df6abf3d57d43e0122ff1b5158bcd8d665c05ee3b453ce4872167995b`.
Cargo.lock SHA-256:
`34972fcbb308007c9f98bfff8de22e868e6a5018a8789a4c31936fd176254f56`.

Final `git status --porcelain` is empty and HEAD remains `69a80a2462393862e16e9092a5c2be0617db3dc7`.
No branch or main ref was changed or pushed by this verification lane. The
integration owner publishes this receipt and raw records on main for global
pickup. These targeted controls do not certify full-suite, release, controller
hardware or live viewport acceptance.

## Raw records

All files are under `/workspace/mios-native-builder-state/verification`.

| File | SHA-256 |
| --- | --- |
| mios-hud-positive-spatial.log | `03a6686b1148f4fb94fa696a6d1fa4ab77a2e35e0f1d3f8cc124695b8d29eb64` |
| mios-hud-negative-linear.log | `30ed4fe971c17f2b3287d36d32819fb62065867388735daab11e878ae84f2a51` |
| mios-hud-restored-spatial.log | `e3b203d94bec4326ec463eec96a59ad70eee84ed445f35179808096d6aef2943` |
