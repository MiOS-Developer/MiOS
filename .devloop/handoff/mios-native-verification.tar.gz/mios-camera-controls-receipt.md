# Compiled camera negative-control receipt

Exact source: `8e0cafe328a6cdf883643cc60edc29cda89c51a1` (camera worktree), UID 1000 inside the MiOS-DEV builder, Rust 1.99.1, target `x86_64-unknown-linux-musl`.

The host invocation set `MIOS_BUILD_WORKDIR=/workspace/mios-camera-continuation/tools/native`. `mios-camera-context.log` confirms the builder's actual working directory, its selected Cargo manifest, source HEAD and original UI hash. Each build/test ran under the shared MiOS heavy lock; no native tests ran outside the builder.

| Actual implementation plant | Native result | Restored result |
| --- | --- | --- |
| Always run legacy axis interpolation in `animate` | Compiled, exit 101; named realtime-step/animate/draw test failed: “the rendered camera lost its realtime pose to the pet frame clock”. Overwritten tuple `(45, 0, (0, 0), 100)` differs from expected realtime `(46, 1, (6, 6), 106)`. | Original source restored byte-for-byte; 1 passed, 0 failed, 429 filtered out; exit 0. |
| Gate reset completion on `!camera_unsettled()` | Compiled, exit 101; named default-reset/cadence test failed: “default reset left motion cadence running forever”. | Original source restored byte-for-byte; 1 passed, 0 failed, 429 filtered out; exit 0. |

Each negative executed one test: 0 passed, 1 failed, 429 filtered out. Neither is a compiler/environment failure. CLI invocations reported zero executed tests and 13 filtered out; they are not counted as positive coverage.

Original UI SHA-256: `512100ce686f1c21c51f0c2285585128cd6eea09be16a00d2b07911fa27fe450`.

The initial positives reported 445 tests because the shared target reused another worktree's artifact. Those initial records are explicitly excluded as source-specific evidence. Both actual plants and both restored positives compiled the camera worktree and reported its 430-test inventory. A redundant forced-rebuild follow-up was interrupted on coordinator instruction before any repeated plants (exit 130); its raw record is retained separately. The four valid negative/restored logs were preserved unchanged.

Both plant mutations affected only the owned `ui.rs` and were removed using its exact original bytes. Final source is unchanged and the camera worktree is clean at the source SHA above. No branch was pushed during verification. These controls do not certify full-suite, release, controller or live-desktop acceptance.

## Raw records

| File under `/workspace/mios-native-builder-state/verification` | SHA-256 |
| --- | --- |
| mios-camera-context.log | `198e5f0c1bef34c7d4597f69e136ce01efc379438ce4ed8542feeee11b515308` |
| mios-camera-negative-overwrite.log | `69e03f8b18c886c97afe2df64b3bea9c9b4d165a259ce58e524c2b9aee63d8e8` |
| mios-camera-restored-overwrite.log | `b5ff6e4a5f2e0b31f886c5717f5e9b976f956231d23186ef34cb34a01e2b49a0` |
| mios-camera-negative-circular-reset.log | `04e382d18a19831486e39e1b4bd678d1c036e0cc1280d7076f5314acbf9e9cd8` |
| mios-camera-restored-circular-reset.log | `ad4815ce300cc28d66285b63c508912c6403919cd4272473f78f253b7340e2b6` |
| mios-camera-baseline-pose.log | `c06340d65e65b7b9bb849148ba8d3cfda1ea3f008e5520df3447025854b4800c` |
| mios-camera-baseline-reset.log | `ad69ea380db691a9d73db14f0d88b221d27dc79069cb88c83ec17729b85e0574` |
| mios-camera-interrupted-repeat.log | `a8f83a2d40d723f17381c1d4cd30438d595d39069ff98b6a743a37b189d3abc0` |
