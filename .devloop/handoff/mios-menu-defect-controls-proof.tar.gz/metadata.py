import pathlib,json
s=pathlib.Path('/home/mios/.local/state/mios/mios-menu-defect-controls');q=json.loads((s/'container-inspect.json').read_text());q=q[0] if isinstance(q,list) else q
assert q['Name']=='podman-MiOS-DEV-mios-menu-defect-controls'
assert q['Image'].removeprefix('sha256:')=='e9ce37c8285d13e1ea1479069cecc7d1f730d2059f318b6f2cdee85558fa8aaf'
(s/'container.env').write_text('name="'+q['Name']+'"\nid="'+q['Id']+'"\nimage="'+q['Image']+'"\n')
