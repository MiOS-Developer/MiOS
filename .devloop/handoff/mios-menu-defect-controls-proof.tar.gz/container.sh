#!/usr/bin/bash
set -euo pipefail
export HOME=/mios-proof/home XDG_CONFIG_HOME=/mios-proof/home/.config CARGO_TARGET_DIR=/mios-proof/target-native GIT_OPTIONAL_LOCKS=0 PYTHONDONTWRITEBYTECODE=1
cd /mios-proof/mios-source
exec /usr/bin/python3 /mios-proof/runner.py
