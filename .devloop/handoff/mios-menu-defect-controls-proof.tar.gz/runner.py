import hashlib,json,os,pathlib,subprocess,time,traceback
ROOT=pathlib.Path('/mios-proof');SOURCE=ROOT/'mios-source';LOGS=ROOT/'logs';LOGS.mkdir(exist_ok=True)
RECEIPT=ROOT/'receipt.json'; started=time.monotonic()
def digest(p):
 with pathlib.Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def persist():
 temporary=RECEIPT.with_suffix('.pending');temporary.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');os.replace(temporary,RECEIPT)
def compile_test(case,stage):
 argv=['cargo','test','--manifest-path',case['manifest'],'--locked','--offline','-p',case['package'],case['target_kind'],case.get('target_name',case['package'])] if case['target_kind']=='--bin' else ['cargo','test','--manifest-path',case['manifest'],'--locked','--offline','-p',case['package'],'--lib']
 if case.get('release'):argv.append('--release')
 argv+=['--target','x86_64-unknown-linux-musl','--no-run','--message-format=json']
 messages=LOGS/(stage+'-compile.jsonl');errors=LOGS/(stage+'-compile.log');begin=time.monotonic()
 with messages.open('xb') as out,errors.open('xb') as err:
  result=subprocess.run(argv,cwd=SOURCE,stdout=out,stderr=err,stdin=subprocess.DEVNULL)
 record={'stage':stage,'kind':'compile','argv':argv,'exit_code':result.returncode,'seconds':time.monotonic()-begin,'stdout':str(messages),'stderr':str(errors),'stdout_sha256':digest(messages),'stderr_sha256':digest(errors)}
 receipt['commands'].append(record);persist()
 if result.returncode:raise RuntimeError('Compilation failure is NOT negative proof: '+stage)
 artifacts=[]
 for line in messages.read_text().splitlines():
  try:item=json.loads(line)
  except json.JSONDecodeError:continue
  if item.get('reason')=='compiler-artifact' and item.get('profile',{}).get('test') and item.get('executable'):
   if item['target']['name']==case['package'].replace('-','_') or item['target']['name']==case['package']:
    artifacts.append(item['executable'])
 if len(set(artifacts))!=1:raise RuntimeError('Expected exactly one compiled focused test executable: '+repr(artifacts))
 executable=pathlib.Path(artifacts[0]);record.update({'executable':str(executable),'binary_sha256':digest(executable)});persist();return executable

def run_test(executable,case,stage,negative=False):
 argv=[str(executable),case['test'],'--exact','--nocapture'];path=LOGS/(stage+'-runtime.log');begin=time.monotonic()
 with path.open('xb') as out:
  result=subprocess.run(argv,cwd=SOURCE,stdout=out,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
 text=path.read_text();record={'stage':stage,'kind':'runtime','argv':argv,'exit_code':result.returncode,'seconds':time.monotonic()-begin,'log':str(path),'log_sha256':digest(path),'binary_sha256':digest(executable),'negative_control':negative}
 receipt['commands'].append(record);persist()
 if negative:
  expected=case['expected_failure']
  if result.returncode!=101 or '1 failed;' not in text or expected not in text:
   raise AssertionError('Negative control did not fail its intended runtime assertion: '+stage)
  record['expected_runtime_failure']=expected
  if case.get('expected_source_assertion'):
   assertion_line=next(i for i,line in enumerate((SOURCE/case['path']).read_text().splitlines(),1) if case['expected_source_assertion'] in line)
   if f'src/ui.rs:{assertion_line}:' not in text or 'left: 0' not in text:
    raise AssertionError('Back-scroll mutant failed outside the intended restoration assertion')
   record['expected_source_assertion']=case['expected_source_assertion']
 else:
  if result.returncode or '1 passed; 0 failed;' not in text:
   raise AssertionError('Focused positive failed or did not execute exactly one test: '+stage)
 persist();return record

common={'manifest':'tools/native/Cargo.toml','target_kind':'--bin','package':'mios-gen','test':'tmux_os::tests::six_row_apps_menu_keeps_middle_pages_and_back_reachable','path':'tools/native/mios-gen/src/tmux_os.rs','expected_failure':'every tiny page must fit'}
launcher={'manifest':'src/mios-rs/Cargo.toml','target_kind':'--bin','package':'miosd','test':'launcher::tests::launcher_find_keeps_quit_space_and_shortcuts_literal','path':'src/mios-rs/miosd/src/launcher.rs','expected_failure':'typing must never activate a row or close the launcher'}
focus={'manifest':'tools/native/Cargo.toml','target_kind':'--lib','package':'mios-tamagotchi','release':True,'test':'ui::menu_backtrack_regressions::keyboard_and_painted_back_restore_deep_parent_focus_and_breadcrumbs','path':'tools/native/mios-tamagotchi/src/ui.rs','expected_failure':'left: 0\n right: 8'}
scroll={**focus,'test':'ui::menu_backtrack_regressions::long_roster_and_scrolled_help_survive_nested_back_resize_and_catalogue_shrink','expected_failure':'assertion `left == right` failed','expected_source_assertion':'assert_eq!(ui.menu_scroll, scroll);'}
cases=[('menu-paging',common,'if rows > 6 {\n            items.push(sep());','if rows > 0 {\n            items.push(sep());'),('literal-search',launcher,'if self.search.is_some() && self.overlay.is_empty() && !self.pending {','if self.search.is_none() && self.overlay.is_empty() && !self.pending {'),('back-focus',focus,'self.menu_selected = parent\n                .selected\n                .min(self.menu_len(parent.menu).saturating_sub(1));','self.menu_selected = parent.selected.min(0);'),('back-scroll',scroll,'self.menu_scroll = parent.scroll;','self.menu_scroll = parent.scroll.min(0);')]
originals={case['path']:(SOURCE/case['path']).read_bytes() for _,case,_,_ in cases}
receipt={'source_commit':'84ae9c5248f147cd831b896a56e98058dd10ce49','status':'running','scope':'private MiOS-DEV source and distinct-inode target cache; no installed/live changes','commands':[],'controls':[],'original_source_sha256':{path:hashlib.sha256(body).hexdigest() for path,body in originals.items()}}
persist()
try:
 # Establish all four focused positives before any production-source defect.
 binaries={}
 for name,case,_,_ in cases:
  key=(case['manifest'],case['package'])
  if key not in binaries:binaries[key]=compile_test(case,'baseline-'+name)
  run_test(binaries[key],case,'baseline-'+name)
 for name,case,before,after in cases:
  path=SOURCE/case['path'];original=originals[case['path']];assert path.read_bytes()==original
  text=original.decode();assert text.count(before)==1,(name,text.count(before))
  modified=text.replace(before,after,1).encode();control={'name':name,'source':case['path'],'original_sha256':hashlib.sha256(original).hexdigest(),'mutation_sha256':hashlib.sha256(modified).hexdigest(),'before':before,'after':after,'status':'mutating'}
  receipt['controls'].append(control);persist()
  try:
   path.write_bytes(modified);control['status']='compiling_mutant';persist()
   mutant=compile_test(case,'mutant-'+name)
   failed=run_test(mutant,case,'mutant-'+name,negative=True)
   control.update({'status':'expected_runtime_failure','negative_log_sha256':failed['log_sha256'],'negative_binary_sha256':failed['binary_sha256']});persist()
  finally:
   path.write_bytes(original);assert path.read_bytes()==original
   control['restored_source_sha256']=digest(path);control['restored_bytes_exact']=True;persist()
  rebuilt=compile_test(case,'restored-'+name)
  positive=run_test(rebuilt,case,'restored-'+name)
  control.update({'status':'passed_compiled_negative_and_restored_positive','restored_binary_sha256':positive['binary_sha256'],'restored_log_sha256':positive['log_sha256']});persist()
  binaries[(case['manifest'],case['package'])]=rebuilt
 for name,case,_,_ in cases:run_test(binaries[(case['manifest'],case['package'])],case,'final-'+name)
 receipt.update({'status':'passed','compiled_negative_controls':4,'initial_focused_passes':4,'expected_runtime_failures':4,'restored_focused_passes':4,'final_focused_passes':4})
except BaseException as error:
 receipt.update({'status':'failed','error':str(error),'traceback':traceback.format_exc()});raise
finally:
 for path,body in originals.items():
  target=SOURCE/path
  if target.read_bytes()!=body:target.write_bytes(body)
 receipt['all_source_bytes_restored']=all((SOURCE/path).read_bytes()==body for path,body in originals.items())
 receipt['final_source_sha256']={path:digest(SOURCE/path) for path in originals}
 receipt['wall_seconds']=time.monotonic()-started;persist()
