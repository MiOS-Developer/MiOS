import hashlib,json,os,pathlib,stat,subprocess
root=pathlib.Path('/home/mios/.local/state/mios/mios-menu-defect-controls');sealed=root.parent/'mios-menu-navigation';src=sealed/'target-native';dst=root/'target-native'
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def tree_metadata(path):
 h=hashlib.sha256();count=0
 for directory,dirs,files in os.walk(path):
  dirs.sort()
  for name in sorted(files):
   p=pathlib.Path(directory)/name;s=p.lstat()
   h.update(json.dumps([str(p.relative_to(path)),s.st_mode,s.st_size,s.st_mtime_ns,s.st_ino,s.st_nlink]).encode()+b'\n');count+=1
 return {'files':count,'metadata_sha256':h.hexdigest()}
if len(os.sys.argv)>1 and os.sys.argv[1]=='restore-source':
 import tarfile
 changes=[]
 with tarfile.open(root/'source-84ae9c5.tar.gz','r:gz') as archive:
  for name in ('tools/native/mios-gen/src/tmux_os.rs','src/mios-rs/miosd/src/launcher.rs','tools/native/mios-tamagotchi/src/ui.rs'):
   original=archive.extractfile(name).read();target=root/'mios-source'/name
   changed=target.read_bytes()!=original
   if changed:target.write_bytes(original)
   assert target.read_bytes()==original
   changes.append({'source':name,'restored_if_needed':changed,'sha256':digest(target)})
 (root/'host-source-restoration.json').write_text(json.dumps(changes,indent=2)+'\n');print(json.dumps(changes));raise SystemExit(0)
if len(os.sys.argv)>1 and os.sys.argv[1]=='verify':
 guard=json.loads((root/'sealed-cache-guard.json').read_text());after=tree_metadata(src);guard['sealed_metadata_after']=after;guard['sealed_cache_unchanged']=after==guard['sealed_metadata_before']
 for p,h in guard['sealed_critical_sha256'].items():assert digest(pathlib.Path(p))==h,p
 for p,h in guard['sealed_source_sha256'].items():assert digest(pathlib.Path(p))==h,p
 (root/'sealed-cache-final.json').write_text(json.dumps(guard,indent=2)+'\n');assert guard['sealed_cache_unchanged'];print(json.dumps({'sealed_cache_unchanged':True,'files':after['files']}));raise SystemExit(0)
assert not dst.exists(),'Independent target cache already exists; refusing overwrite'
critical=[p for p in (src/'x86_64-unknown-linux-musl/release').iterdir() if p.name in {'mios-gen','miosd','mios-tamagotchi'}]
assert {p.name for p in critical}=={'mios-gen','miosd','mios-tamagotchi'}
sealed_sources=[sealed/'mios-source'/p for p in ('tools/native/mios-gen/src/tmux_os.rs','src/mios-rs/miosd/src/launcher.rs','tools/native/mios-tamagotchi/src/ui.rs')]
guard={'sealed_source_sha256':{str(p):digest(p) for p in sealed_sources},'sealed_metadata_before':tree_metadata(src),'sealed_critical_sha256':{str(p):digest(p) for p in critical}}
subprocess.run(['cp','-a','--reflink=always',str(src),str(dst)],check=True)
regular=0;shared=[]
for directory,_,files in os.walk(src):
 for name in files:
  p=pathlib.Path(directory)/name;s=p.lstat()
  if stat.S_ISREG(s.st_mode):
   q=dst/p.relative_to(src);t=q.lstat();assert s.st_size==t.st_size
   regular+=1
   if (s.st_dev,s.st_ino)==(t.st_dev,t.st_ino):shared.append(str(p.relative_to(src)))
assert not shared,shared[:10]
guard.update({'regular_files_compared':regular,'shared_source_inodes':0,'clone_method':'cp -a --reflink=always; no hardlinks to sealed source'})
(root/'sealed-cache-guard.json').write_text(json.dumps(guard,indent=2)+'\n')
subprocess.run(['cp','-a','--reflink=always','/home/mios/.local/state/mios/mios-tamagotchi-graphics-dev/cargo',str(root/'cargo')],check=True)
print(json.dumps({'cache_clone':guard,'cargo_home_private':True}))
