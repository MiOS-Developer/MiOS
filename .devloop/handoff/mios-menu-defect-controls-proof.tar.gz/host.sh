#!/usr/bin/bash
set -euo pipefail
proof=/home/mios/.local/state/mios/mios-menu-defect-controls
exec > "$proof/host.log" 2>&1
finish() {
  task_rc=$?
  trap - EXIT
  /usr/bin/python3 "$proof/cache.py" restore-source > "$proof/host-source-restoration.log" 2>&1 || task_rc=97
  if test -f "$proof/sealed-cache-guard.json"; then
    /usr/bin/python3 "$proof/cache.py" verify > "$proof/sealed-cache-final.log" 2>&1 || task_rc=98
  fi
  printf '%s\n' "$task_rc" > "$proof/host.exit"
  exit "$task_rc"
}
trap finish EXIT
printf '%s\n' '{"phase":"waiting-memory"}' > "$proof/job-state.json"
/usr/bin/mios-gen mem-admit --root "$proof/mios-source" --wait > "$proof/admission-before-lock.json"
printf '%s\n' '{"phase":"waiting-heavy-lock"}' > "$proof/job-state.json"
exec 8>/home/mios/mios-desktop-work-1/heavy.lock
flock 8
exec 9>/var/lib/mios-build/heavy.lock
flock 9
/usr/bin/mios-gen mem-admit --root "$proof/mios-source" > "$proof/admission-before-build.json"
printf '%s\n' '{"phase":"cloning-independent-cache"}' > "$proof/job-state.json"
/usr/bin/python3 "$proof/cache.py" > "$proof/cache-clone.log" 2>&1
printf '%s\n' '{"phase":"creating-container"}' > "$proof/job-state.json"
podman --remote --url unix:///run/user/1000/podman/podman.sock create --name podman-MiOS-DEV-mios-menu-defect-controls --pull=never --network=none --memory=3g --memory-swap=3g --cpus=2 --userns=keep-id --user=1000:1000 --security-opt label=disable -v /usr:/usr:ro -v /.git:/.git:ro -v "$proof:/mios-proof:rw" -v "$proof/container.env:/run/.containerenv:ro" -v /home/mios/.rustup/toolchains/stable-x86_64-unknown-linux-gnu:/rust-toolchain:ro -v "$proof/cargo:/mios-cargo:rw" -v /home/mios/.cargo/registry:/mios-cargo/registry:ro --env PATH=/rust-toolchain/bin:/usr/bin:/usr/sbin:/bin --env RUSTC=/rust-toolchain/bin/rustc --env RUSTDOC=/rust-toolchain/bin/rustdoc --env CARGO_HOME=/mios-cargo --env CARGO_BUILD_JOBS=1 --env 'RUSTFLAGS=-C target-feature=+crt-static' --env CARGO_TARGET_X86_64_UNKNOWN_LINUX_MUSL_LINKER=/rust-toolchain/lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld --entrypoint /usr/bin/bash e9ce37c8285d13e1ea1479069cecc7d1f730d2059f318b6f2cdee85558fa8aaf --noprofile --norc /mios-proof/container.sh > "$proof/container.id"
podman --remote --url unix:///run/user/1000/podman/podman.sock inspect podman-MiOS-DEV-mios-menu-defect-controls > "$proof/container-inspect.json"
/usr/bin/python3 "$proof/metadata.py"
printf '%s\n' '{"phase":"running-compiled-controls"}' > "$proof/job-state.json"
podman --remote --url unix:///run/user/1000/podman/podman.sock start --attach podman-MiOS-DEV-mios-menu-defect-controls > "$proof/container.log" 2>&1
printf '%s\n' '{"phase":"controls-finished"}' > "$proof/job-state.json"
