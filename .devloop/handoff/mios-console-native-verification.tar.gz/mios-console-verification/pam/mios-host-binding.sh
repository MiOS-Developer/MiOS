#!/usr/bin/bash
set -euo pipefail
proof=/home/mios/.local/state/mios/mios-console-login-ownership
trap 'rc=$?; printf "%s\n" "$rc" > "$proof/binding-host.exit"' EXIT
exec > "$proof/binding-host.log" 2>&1
mios-gen mem-admit --root "$proof/mios-source" --wait > "$proof/binding-admission.json"
exec 9>/var/lib/mios-build/heavy.lock
flock 9
mios-gen mem-admit --root "$proof/mios-source" > "$proof/binding-admission-before-create.json"
podman --remote --url unix:///run/user/1000/podman/podman.sock create --name podman-MiOS-DEV-mios-console-binding --pull=never --network=none --memory=3g --memory-swap=3g --cpus=2 --userns=keep-id --user=1000:1000 --security-opt label=disable -v /usr:/usr:ro -v /.git:/.git:ro -v "$proof:/mios-proof:rw" -v /home/mios/.local/state/mios/mios-global-agent-inventory/target-native:/mios-proof/target-native:rw -v /home/mios/.rustup/toolchains/stable-x86_64-unknown-linux-gnu:/rust-toolchain:ro -v /home/mios/.local/state/mios/mios-tamagotchi-graphics-dev/cargo:/mios-cargo:rw -v /home/mios/.cargo/registry:/mios-cargo/registry:ro --env PATH=/rust-toolchain/bin:/usr/bin:/usr/sbin:/bin --env RUSTC=/rust-toolchain/bin/rustc --env RUSTDOC=/rust-toolchain/bin/rustdoc --env CARGO_HOME=/mios-cargo --env CARGO_BUILD_JOBS=1 --env 'RUSTFLAGS=-C target-feature=+crt-static' --env CARGO_TARGET_X86_64_UNKNOWN_LINUX_MUSL_LINKER=/rust-toolchain/lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld --entrypoint /usr/bin/bash e9ce37c8285d13e1ea1479069cecc7d1f730d2059f318b6f2cdee85558fa8aaf --noprofile --norc /mios-proof/mios-container-binding.sh > "$proof/container.id"
podman --remote --url unix:///run/user/1000/podman/podman.sock start --attach podman-MiOS-DEV-mios-console-binding
