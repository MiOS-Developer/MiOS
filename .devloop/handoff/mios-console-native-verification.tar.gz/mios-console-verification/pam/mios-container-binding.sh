#!/usr/bin/bash
set -euo pipefail
trap 'rc=$?; printf "%s\n" "$rc" > /mios-proof/binding-inside.exit' EXIT
export HOME=/mios-proof/home XDG_CONFIG_HOME=/mios-proof/home/.config CARGO_TARGET_DIR=/mios-proof/target-native GIT_OPTIONAL_LOCKS=0 PYTHONDONTWRITEBYTECODE=1
cd /mios-proof/mios-source
rustfmt --edition 2021 --config skip_children=true src/mios-rs/miosd/src/main.rs src/mios-rs/miosd/src/console_session.rs > /mios-proof/binding-format.log 2>&1
cargo test --manifest-path src/mios-rs/Cargo.toml --locked --offline -p miosd --target x86_64-unknown-linux-musl > /mios-proof/binding-tests.log 2>&1
python3 /mios-proof/mios-console-binding-controls.py > /mios-proof/binding-controls.log 2>&1
cargo clippy --manifest-path src/mios-rs/Cargo.toml --locked --offline -p miosd --all-targets --target x86_64-unknown-linux-musl -- -D warnings > /mios-proof/binding-clippy.log 2>&1
cargo build --manifest-path src/mios-rs/Cargo.toml --locked --offline -p miosd --release --target x86_64-unknown-linux-musl > /mios-proof/binding-release.log 2>&1
/usr/bin/mios-gate static-linkage --root "$PWD" --binary /mios-proof/target-native/x86_64-unknown-linux-musl/release/miosd --arch x86_64 --format json > /mios-proof/binding-static.json
/usr/bin/mios-gen sync --root "$PWD" > /mios-proof/binding-generation.log 2>&1
python3 tools/ci-suites.py --check > /mios-proof/binding-suites.log 2>&1
for gate in credential-literals phase-registry ratchet-direction signature-policy version-literals-ssot; do
 /usr/bin/mios-gate "$gate" --root "$PWD" > "/mios-proof/binding-$gate.log" 2>&1
done
