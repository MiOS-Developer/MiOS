import subprocess
code='''import ctypes, pathlib, tempfile, json, os
s=pathlib.Path('/home/mios/.local/state/mios/mios-console-login-ownership')
with tempfile.TemporaryDirectory(prefix='mios-pam-session-',dir=s) as folder:
 d=pathlib.Path(folder);d.chmod(0o700);result=d/'identity.json';probe=d/'probe.py'
 probe.write_text("import os,pathlib,json,sys;p=pathlib.Path('/proc/self');parent=pathlib.Path('/proc')/str(os.getppid());pathlib.Path(sys.argv[1]).write_text(json.dumps({'pid':os.getpid(),'sid':os.getsid(0),'ppid':os.getppid(),'parent_sid':os.getsid(os.getppid()),'self_stat':(p/'stat').read_text(),'parent_stat':(parent/'stat').read_text()}))")
 (d/'mios-console-pam-probe').write_text('session required pam_exec.so /usr/bin/python3 '+str(probe)+' '+str(result)+'\\n')
 pam=ctypes.CDLL('libpam.so.0');callback=ctypes.CFUNCTYPE(ctypes.c_int,ctypes.c_int,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p)
 class Conversation(ctypes.Structure):_fields_=[('conv',callback),('data',ctypes.c_void_p)]
 def refuse(*args):return 19
 cb=callback(refuse);conv=Conversation(cb,None);handle=ctypes.c_void_p()
 pam.pam_start_confdir.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.POINTER(Conversation),ctypes.c_char_p,ctypes.POINTER(ctypes.c_void_p)]
 pam.pam_open_session.argtypes=[ctypes.c_void_p,ctypes.c_int];pam.pam_close_session.argtypes=[ctypes.c_void_p,ctypes.c_int];pam.pam_end.argtypes=[ctypes.c_void_p,ctypes.c_int]
 status=pam.pam_start_confdir(b'mios-console-pam-probe',b'mios',ctypes.byref(conv),os.fsencode(d),ctypes.byref(handle));assert status==0,status
 try:
  status=pam.pam_open_session(handle,0);assert status==0,status
  opened=json.loads(result.read_text());assert opened['sid']==opened['pid'] and opened['sid']!=opened['parent_sid']
  status=pam.pam_close_session(handle,0);assert status==0,status
  closed=json.loads(result.read_text());assert closed['sid']==closed['pid'] and closed['pid']!=opened['pid']
 finally:pam.pam_end(handle,status)
 receipt={'installed_pam_exec_creates_detached_child_sessions':True,'open':opened,'close':closed,'scope':'Private pam_start_confdir session-only fixture; no authentication call or live PAM/VT mutation'}
 p=s/'pam-exec-session-proof.json';p.write_text(json.dumps(receipt,indent=2)+'\\n');os.chown(p,1000,1000);os.chmod(p,0o600)
 print(json.dumps({'pam_session_only_probe':'passed','child_session_differs_from_parent':True,'private_fixture_only':True}))
'''
p=subprocess.run(['sudo','-n','python3','-c',code],text=True,capture_output=True,timeout=15);print(p.stdout+p.stderr);raise SystemExit(p.returncode)
