import pathlib,subprocess,json
r=pathlib.Path('/mios-proof/mios-source');s=r.parent;p=r/'src/mios-rs/miosd/src/console_session.rs';original=p.read_text();rows=[]
cases=[('handoff',original.replace('Ok(Some(current.uid))','Ok(None)'), 'console_session::tests::authenticated_open_and_matching_close_preserve_mode_and_group'),('delayed-logout',original.replace('left.session,','right.session,',1),'console_session::tests::delayed_logout_cannot_steal_a_new_session_or_changed_device'),('privileged-policy',original.replace('mios_resolver::resolve_projection(root)','mios_resolver::resolve_merged(Some(root), false)'),'console_session::tests::privileged_policy_ignores_environment_loader_overrides'),('parent-session',original.replace('session != parent','session == parent'),'console_session::tests::detached_pam_child_uses_only_the_live_parent_vt_identity')]

try:
 for name,mutant,test in cases:
  assert mutant!=original;p.write_text(mutant)
  cmd=['cargo','test','--manifest-path','src/mios-rs/Cargo.toml','--locked','--offline','-p','miosd','--target','x86_64-unknown-linux-musl',test,'--','--exact']
  with (s/f'binding-mutant-{name}.log').open('wb') as log:code=subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
  text=(s/f'binding-mutant-{name}.log').read_text();assert code==101 and '1 failed;' in text and 'error[E' not in text,text[-5000:]
  p.write_text(original)
  with (s/f'binding-restored-{name}.log').open('wb') as log:restored=subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
  assert restored==0
  rows.append({'case':name,'mutant_exit':code,'intended_failed_assertions':1,'restored_exit':restored})
finally:p.write_text(original)
(s/'binding-controls.json').write_text(json.dumps(rows,indent=2)+'\n')
