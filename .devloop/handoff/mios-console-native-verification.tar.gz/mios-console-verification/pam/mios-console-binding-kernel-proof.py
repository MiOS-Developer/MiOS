import subprocess
code='''import pathlib,subprocess,json,hashlib,os,socket,time,signal,stat,tempfile,shutil,shlex
s=pathlib.Path('/home/mios/.local/state/mios/mios-console-login-ownership');g=s.parent/'mios-global-agent-inventory'
assert (s/'binding-inside.exit').read_text().strip()=='0'
binary=g/'target-native/x86_64-unknown-linux-musl/release/miosd'
receipt=s/'kernel-binding-acceptance.json'
if receipt.exists():print(receipt.read_text());raise SystemExit(0)
assert pathlib.Path('/sys/class/tty/tty0/active').read_text().strip()=='tty1'
vt=63;terminal=pathlib.Path('/dev/tty63');before=terminal.stat()
assert stat.S_ISCHR(before.st_mode) and os.major(before.st_rdev)==4 and os.minor(before.st_rdev)==vt and before.st_uid==0
for proc in pathlib.Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  fields=(proc/'stat').read_text().rsplit(') ',1)[1].split()
  assert int(fields[4])!=before.st_rdev, 'VT63 is already in use; preserved'
  for entry in (proc/'fd').iterdir():
   try:
    metadata=entry.stat()
    assert not (stat.S_ISCHR(metadata.st_mode) and metadata.st_rdev==before.st_rdev), 'VT63 has an existing open descriptor; preserved'
   except (FileNotFoundError,PermissionError):pass
 except (FileNotFoundError,PermissionError):pass
preserved={pid:pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(') ',1)[1].split()[19] for pid in [2137102,3710964,3712497,1786293]}
rootstate=pathlib.Path(tempfile.mkdtemp(prefix='mios-console-login-proof-',dir='/run'));rootstate.chmod(0o700)
worker=None;child=None;owns_vt=False;probe={}
bridge_state=pathlib.Path(tempfile.mkdtemp(prefix='mios-console-bridge-proof-',dir='/var/tmp'));os.chown(bridge_state,1000,1000);bridge_state.chmod(0o700)
try:
 fixture=rootstate/'greetd';fixture.write_text('auth required pam_permit.so\\naccount required pam_permit.so\\nsession required pam_exec.so log='+str(rootstate/'helper.log')+' '+str(binary)+' console-session\\n');fixture.chmod(0o600)
 config=rootstate/'mios.toml';source=(s/'mios-source/usr/share/mios/mios.toml').read_text();old='state_directory = "/run/mios-console-sessions"';assert source.count(old)==1
 config.write_text(source.replace(old,'state_directory = '+json.dumps(str(rootstate/'leases'))));config.chmod(0o644)
 subprocess.run(['/usr/bin/mount','--bind',str(fixture),'/etc/pam.d/greetd'],check=True,capture_output=True)
 subprocess.run(['/usr/bin/mount','--bind',str(config),'/usr/share/mios/mios.toml'],check=True,capture_output=True)
 parent,peer=socket.socketpair(socket.AF_UNIX,socket.SOCK_DGRAM);parent.settimeout(8)
 with (rootstate/'worker.log').open('wb') as log:
  worker=subprocess.Popen(['/usr/bin/greetd','--session-worker',str(peer.fileno())],pass_fds=(peer.fileno(),),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
 peer.close()
 def send(message):parent.send(json.dumps(message).encode())
 def receive():
  data=json.loads(parent.recv(10240));assert not isinstance(data,dict) or 'Error' not in data,data;return data
 send({'InitiateLogin':{'service':'greetd','class':'User','user':'mios','authenticate':False,'tty':{'Terminal':{'path':str(terminal),'vt':vt,'switch':False}},'source_profile':False,'listener_path':''}})
 assert receive()=='Success'
 client_code="import os,time;os.chmod('/dev/tty63',0o620);os.chown('/dev/tty63',-1,os.getgid());os.write(1,bytes([27])+b'[?1000h'+bytes([27])+b'[?1006h');time.sleep(4)"
 send({'Args':{'env':[],'cmd':['/usr/bin/mios-inputd','console-bridge','--vt',str(vt),'--log',str(bridge_state/'bridge.jsonl'),'--','/usr/bin/python3','-c',shlex.quote(client_code)]}});assert receive()=='Success'
 owns_vt=True;send('Start');reply=receive();assert isinstance(reply,dict) and 'FinalChildPid' in reply,reply;child=int(reply['FinalChildPid'])
 current=terminal.stat();assert current.st_uid==1000
 assert pathlib.Path('/sys/class/tty/tty0/active').read_text().strip()=='tty1'
 deadline=time.monotonic()+3;gpm=False
 while time.monotonic()<deadline:
  try:
   args=pathlib.Path(f'/proc/{child}/cmdline').read_bytes()
   if b'console-bridge' not in args:time.sleep(.05);continue
   gpm=any(str(fd.readlink()).startswith('socket:[') for fd in pathlib.Path(f'/proc/{child}/fd').iterdir())
   if gpm:break
  except FileNotFoundError:pass
  time.sleep(.05)
 assert gpm,'Scoped console bridge has no GPM connection after authenticated ownership handoff'
 lease=json.loads((rootstate/'leases/tty63.json').read_text());assert lease['session']==worker.pid and lease['uid']==1000
 worker.wait(timeout=8);assert worker.returncode==0
 after=terminal.stat();assert after.st_uid==0 and after.st_gid==1000 and stat.S_IMODE(after.st_mode)==0o620
 assert (rootstate/'leases/tty63.json').read_bytes()==b''
 for pid,start in preserved.items():assert pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(') ',1)[1].split()[19]==start
 assert pathlib.Path('/sys/class/tty/tty0/active').read_text().strip()=='tty1'
 probe={'passed':True,'artifact_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'user_changed_mode_and_group_preserved':True,'vt':vt,'active_vt_preserved':1,'actual_greetd_worker_pid':worker.pid,'actual_unprivileged_console_bridge_pid':child,'open_uid':1000,'close_uid':0,'group_and_mode_preserved':True,'gpm_connected':True,'lease_reclaimed':True,'adopted_processes_preserved':preserved,'scope':'Private mount namespace PAM/config fixture, actual installed greetd+pam_exec and kernel VT, no live authentication/config/active VT change'}
 receipt.write_text(json.dumps(probe,indent=2)+'\\n');os.chown(receipt,1000,1000);os.chmod(receipt,0o600);print(json.dumps(probe))
finally:
 if child is not None and pathlib.Path(f'/proc/{child}').exists():
  args=pathlib.Path(f'/proc/{child}/cmdline').read_bytes()
  fields=pathlib.Path(f'/proc/{child}/stat').read_text().rsplit(') ',1)[1].split()
  if int(fields[1])==worker.pid:os.kill(child,signal.SIGTERM)
 if worker is not None and worker.poll() is None:
  try:worker.wait(timeout=3)
  except subprocess.TimeoutExpired:worker.terminate();worker.wait(timeout=3)
 if owns_vt:
  current=terminal.stat();assert current.st_ino==before.st_ino and current.st_rdev==before.st_rdev
  os.chown(terminal,before.st_uid,before.st_gid);os.chmod(terminal,stat.S_IMODE(before.st_mode))
 if not probe:
  failure={name:(rootstate/name).read_text(errors='replace')[-5000:] for name in ['helper.log','worker.log'] if (rootstate/name).exists()}
  failure['root_modes']={str(path):oct(path.stat().st_mode & 0o7777) for path in [pathlib.Path('/'),pathlib.Path('/run')]}
  if (bridge_state/'bridge.jsonl').exists():failure['bridge_log']=(bridge_state/'bridge.jsonl').read_text()[-5000:]
  try:failure['fixture_vt_output']=pathlib.Path('/dev/vcs63').read_bytes().decode(errors='replace')[-4000:]
  except OSError:pass
  failure['active_vt']=pathlib.Path('/sys/class/tty/tty0/active').read_text().strip()
  p=s/'kernel-pam-failure.json';p.write_text(json.dumps(failure,indent=2)+'\\n');os.chown(p,1000,1000);os.chmod(p,0o600);print(json.dumps(failure))
 # Keep only the sanitized durable receipt; this namespace's fixture mounts vanish on exit.
 shutil.rmtree(rootstate)
 shutil.rmtree(bridge_state)
'''
p=subprocess.run(['sudo','-n','/usr/bin/unshare','--mount','--propagation','private','/usr/bin/python3','-c',code],text=True,capture_output=True,timeout=30)
print(p.stdout+p.stderr);raise SystemExit(p.returncode)
