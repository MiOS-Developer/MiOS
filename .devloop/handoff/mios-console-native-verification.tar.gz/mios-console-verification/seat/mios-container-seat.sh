#!/usr/bin/bash
set -euo pipefail
trap 'rc=$?; printf "%s\n" "$rc" > /mios-proof/canonical-inside.exit' EXIT
export HOME=/mios-proof/home XDG_CONFIG_HOME=/mios-proof/home/.config CARGO_TARGET_DIR=/mios-proof/target-native GIT_OPTIONAL_LOCKS=0 PYTHONDONTWRITEBYTECODE=1
cd /mios-proof/mios-source
python3 /mios-proof/mios-seat-controls.py > /mios-proof/canonical-controls.log 2>&1
cargo test --manifest-path tools/native/Cargo.toml --locked --offline -p mios-inputd --target x86_64-unknown-linux-musl > /mios-proof/canonical-tests.log 2>&1
cargo clippy --manifest-path tools/native/Cargo.toml --locked --offline -p mios-inputd --all-targets --target x86_64-unknown-linux-musl -- -D warnings > /mios-proof/canonical-clippy.log 2>&1
cargo build --manifest-path tools/native/Cargo.toml --locked --offline -p mios-inputd --release --target x86_64-unknown-linux-musl > /mios-proof/canonical-release.log 2>&1
/usr/bin/mios-gate static-linkage --root "$PWD" --binary /mios-proof/target-native/x86_64-unknown-linux-musl/release/mios-inputd --arch x86_64 --format json > /mios-proof/canonical-static.json
