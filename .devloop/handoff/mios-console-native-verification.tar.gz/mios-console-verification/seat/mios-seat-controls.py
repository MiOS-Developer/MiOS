import pathlib,subprocess,json
r=pathlib.Path('/mios-proof/mios-source');s=r.parent;p=r/'tools/native/mios-inputd/src/runtime.rs';original=p.read_text();old=(s/'runtime.rs.old-classifier-mutant').read_text()
assert old!=original and 'Actual Blade physical VT tmux-os state' in old
cmd=['cargo','test','--manifest-path','tools/native/Cargo.toml','--locked','--offline','-p','mios-inputd','--target','x86_64-unknown-linux-musl','runtime::tests::seat_view_selects_console_graphical_or_foreign','--','--exact']
try:
 p.write_text(old)
 with (s/'canonical-old-classifier.log').open('wb') as log:code=subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
 text=(s/'canonical-old-classifier.log').read_text();assert code==101 and '1 failed;' in text and 'error[E' not in text,text[-5000:]
finally:p.write_text(original)
with (s/'canonical-restored-classifier.log').open('wb') as log:restored=subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
assert restored==0
(s/'canonical-controls.json').write_text(json.dumps({'old_classifier_exit':code,'intended_assertions_failed':1,'restored_exit':restored},indent=2)+'\n')
