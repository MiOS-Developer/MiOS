"""
RAGFlow chat completion configuration.
"""
